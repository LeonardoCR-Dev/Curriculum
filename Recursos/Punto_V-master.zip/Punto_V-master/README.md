# Punto_V
Este es un proyecto de punto de venta de prueba para usar git!!!
